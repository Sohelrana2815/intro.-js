### Task-3

You task is to divide the given number by 5 and show the remainder as the output.

**Input:**
</br>
The first line of the input contains the number.

**Output:**
</br>
Print the remainder.

---

**Sample Input:**
</br>
119

**Sample Output:**
</br>
4
